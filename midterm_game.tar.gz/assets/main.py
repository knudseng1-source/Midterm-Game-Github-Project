import pygame
import random
import sys
import asyncio

pygame.init()

white = (255, 255, 255)
red = (255, 0, 0)
green = (0, 255, 0)
blue = (0, 0, 255)
black = (0, 0, 0)

width = 1000
height = 800
pixel = 150

screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("Midterm Game")

playerXPosition = (width / 2) - (pixel - 20)
playerYPosition = height - pixel - 20
playerXPositionChange = 0
playerYPositionChange = 0

player_rect = pygame.Rect(playerXPosition, playerYPosition, 100, 100)

blockXPosition = random.randint(0, width - pixel)
blockYPosition = 0 - pixel
blockYPositionChange = 3

block_rect = pygame.Rect(blockXPosition, blockYPosition, 200, 200)

score = 0
collision = False

def show_score(color, font, size):
    score_font = pygame.font.SysFont(font, size)
    score_surface = score_font.render("Score: " + str(score), True, color)
    screen.blit(score_surface, (0, 0))

async def main():
    global playerXPosition, playerYPosition, playerXPositionChange, playerYPositionChange
    global blockXPosition, blockYPosition, score, collision, player_rect, block_rect

    running = True
    while running:
        screen.fill((30, 30, 30))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RIGHT:
                    playerXPositionChange = 4
                if event.key == pygame.K_LEFT:
                    playerXPositionChange = -4
                if event.key == pygame.K_UP:
                    playerYPositionChange = -4
                if event.key == pygame.K_DOWN:
                    playerYPositionChange = 4
            if event.type == pygame.KEYUP:
                if event.key in (pygame.K_RIGHT, pygame.K_LEFT):
                    playerXPositionChange = 0
                if event.key in (pygame.K_UP, pygame.K_DOWN):
                    playerYPositionChange = 0

        if player_rect.colliderect(block_rect):
            if not collision:
                score += 1
                collision = True
        else:
            collision = False

        if score >= 20:
            font = pygame.font.SysFont('Arial', 60)
            win_surface = font.render("You Win!", True, green)
            screen.blit(win_surface, (width // 2 - 150, height // 2))
            pygame.display.update()
            await asyncio.sleep(3)
            running = False

        if playerXPosition >= width - pixel:
            playerXPosition = width - pixel
        if playerXPosition <= 0:
            playerXPosition = 0
        if playerYPosition >= height - pixel:
            playerYPosition = height - pixel
        if playerYPosition <= 0:
            playerYPosition = 0

        playerXPosition += playerXPositionChange
        playerYPosition += playerYPositionChange
        player_rect.x = playerXPosition
        player_rect.y = playerYPosition

        blockYPosition += blockYPositionChange
        if blockYPosition >= height:
            blockYPosition = 0 - pixel
            blockXPosition = random.randint(0, width - pixel)
        block_rect.x = blockXPosition
        block_rect.y = blockYPosition

        pygame.draw.rect(screen, blue, player_rect)
        pygame.draw.rect(screen, red, block_rect)

        show_score(white, 'Arial', 30)
        pygame.display.update()
        await asyncio.sleep(0)

asyncio.run(main())