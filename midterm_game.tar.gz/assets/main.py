import pygame
import random
import sys
import asyncio
import os

pygame.init()

BASE = os.path.dirname(os.path.abspath(__file__))

WIDTH  = 1000
HEIGHT = 800
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Racing Game")

WHITE  = (255, 255, 255)
YELLOW = (255, 220, 0)
GREEN  = (0, 255, 0)

# Load images
track_img   = pygame.transform.scale(pygame.image.load(os.path.join(BASE, "track.png")),   (WIDTH, HEIGHT))
car_img     = pygame.transform.scale(pygame.image.load(os.path.join(BASE, "car.png")),     (200, 90))
numbers_img = pygame.transform.scale(pygame.image.load(os.path.join(BASE, "numbers.png")), (80, 80))

CAR_W, CAR_H = car_img.get_size()

ROAD_LEFT  = 150
ROAD_RIGHT = 850

playerX = WIDTH // 2 - CAR_W // 2
playerY = HEIGHT - CAR_H - 20
playerXChange = 0
player_rect = pygame.Rect(playerX, playerY, CAR_W, CAR_H)

numX     = random.randint(ROAD_LEFT + 10, ROAD_RIGHT - 90)
numY     = -80
num_rect = pygame.Rect(numX, numY, 80, 80)
NUM_SPEED = 5

score     = 0
collision = False


def show_score():
    font = pygame.font.SysFont('Arial', 36, bold=True)
    surf = font.render(f"Score: {score} / 20", True, WHITE)
    screen.blit(surf, (10, 10))


async def main():
    global playerX, playerXChange, numX, numY
    global score, collision, player_rect, num_rect

    running = True
    while running:
        screen.blit(track_img, (0, 0))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RIGHT:
                    playerXChange = 6
                if event.key == pygame.K_LEFT:
                    playerXChange = -6
            if event.type == pygame.KEYUP:
                if event.key in (pygame.K_RIGHT, pygame.K_LEFT):
                    playerXChange = 0

        playerX += playerXChange
        playerX = max(ROAD_LEFT + 5, min(playerX, ROAD_RIGHT - CAR_W - 5))
        player_rect.x = playerX

        numY += NUM_SPEED
        num_rect.x = numX
        num_rect.y = numY

        if num_rect.colliderect(player_rect):
            if not collision:
                score    += 1
                collision = True
                numY  = -80
                numX  = random.randint(ROAD_LEFT + 10, ROAD_RIGHT - 90)
        else:
            collision = False

        if numY >= HEIGHT:
            numY = -80
            numX = random.randint(ROAD_LEFT + 10, ROAD_RIGHT - 90)

        screen.blit(numbers_img, (numX, numY))
        screen.blit(car_img,     (playerX, playerY))
        show_score()

        if score >= 20:
            font = pygame.font.SysFont('Arial', 80, bold=True)
            win  = font.render("You Win!", True, YELLOW)
            screen.blit(win, (WIDTH // 2 - win.get_width() // 2, HEIGHT // 2 - 50))
            pygame.display.update()
            await asyncio.sleep(3)
            running = False

        pygame.display.update()
        await asyncio.sleep(0)


asyncio.run(main())
